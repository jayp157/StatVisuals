
create_summary <- function(data) {
  structure(data, class = "summary_data")
}


print.summary_data <- function(x) {
  cat("Summary of the dataset:\n")
  print(summary(x))
}


setClass(
  "BiomarkerAnalysis",
  slots = list(data = "data.frame", results = "list")
)

setGeneric("calculate_stats", function(object) standardGeneric("calculate_stats"))

setMethod(
  "calculate_stats",
  "BiomarkerAnalysis",
  function(object) {
    object@results <- list(mean = colMeans(object@data, na.rm = TRUE))
    return(object)
  }
)

setGeneric("show_results", function(object) standardGeneric("show_results"))

setMethod(
  "show_results",
  "BiomarkerAnalysis",
  function(object) {
    print(object@results)
  }
)
