show_patients <- function() {
  print(patients)
}

show_biomarkers <- function() {
  print(biomarkers)
}
