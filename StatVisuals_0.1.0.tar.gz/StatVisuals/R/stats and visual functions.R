




plot_biomarkers <- function(data, x, y) {
  ggplot(data, aes_string(x = x, y = y)) +
    geom_point(color = "blue") +
    theme_minimal() +
    labs(title = "Biomarker Scatter Plot", x = x, y = y)
}
